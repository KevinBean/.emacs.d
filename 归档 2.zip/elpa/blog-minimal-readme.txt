Blog-minimal is a simple static site generator based on org mode.
It's so simple that others can hack it quickly and then create and
modify their own sites.

you need add (require 'blog-minimal) to you .emacs file
then config your blog-minimal-vars, execute (blog-minimal-init)
