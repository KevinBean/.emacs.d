A shameless extraction of Spacemacs’ startup screen, with sections for
bookmarks, projectil projects and more.
